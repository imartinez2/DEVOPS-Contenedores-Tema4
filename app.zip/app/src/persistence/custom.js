function getCn(){
    return "Demo";
}

module.exports = {
    getCn
};