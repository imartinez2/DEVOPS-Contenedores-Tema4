#Creacióm de APP
docker compose up -d