#Eliminar la aplicación
docker compose down